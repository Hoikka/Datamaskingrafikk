# Oblig 3 - DTE-2800

## Gruppe 5

Eskil Hoikka & Morten Solbakken

## Installasjon
Last ned og installer [Node.js](https://nodejs.org/en/download/).
<br>
Kjør deretter følgende kommandoer fra prosjektmappa:

``` bash
# Installer avhengigheter (kun første gang)
npm install

# Installer lil-gui
npm install --save lil-gui

# Kjør server på localhost:8080
npm run dev

# Kompiler/bygg for produksjon (blir liggende i dist/ directory)
npm run build
```